from PIL import Image
import sys
def jpg2png(input,output):

    im = Image.open(input)
    im.save(output)

if __name__ == "__main__":
    if jpg2png(sys.argv[1],sys.argv[2]) is True:
        print("ok")



