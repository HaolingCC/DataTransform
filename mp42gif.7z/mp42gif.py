import sys
from moviepy.editor import *
def transform(input,output):
    clip=(VideoFileClip(input))
    # clip.write_gif(output)
    clip.write_gif(output+"\\output.gif")
  

if __name__ == "__main__":
    if transform(sys.argv[1],sys.argv[2]) is True:
        print("ok")